<template>
  <el-card>
    <el-form :model="formData" size="mini" inline>
      <el-form-item label="订单号">
        <el-input v-model="formData.orderNo"></el-input>
      </el-form-item>
      <el-form-item label="收货人">
        <el-input v-model="formData.consignee"></el-input>
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="formData.phone"></el-input>
      </el-form-item>
      <el-form-item label="订单状态">
        <el-select v-model="formData.orderState">
          <el-option value="已受理">已受理</el-option>
          <el-option value="派送中">派送中</el-option>
          <el-option value="已完成">已完成</el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="选择时间">
        <el-date-picker
          v-model="formData.date"
          type="datetimerange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          value-format="yyyy-MM-dd HH:mm:ss"
          format="yyyy-MM-dd HH:mm:ss"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleSearch">查询</el-button>
        <el-button @click="reset">重置</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData" border :style="{width:h+'px'}">
      <el-table-column fixed prop="orderNo" label="订单号"></el-table-column>
      <el-table-column label="下单时间">
        <template slot-scope="scope">{{scope.row.orderTime |normalizeHMS}}</template>
      </el-table-column>
      <el-table-column prop="phone" label="手机号" width="120"></el-table-column>
      <el-table-column prop="consignee" label="收货人"></el-table-column>
      <el-table-column prop="deliverAddress" label="配送地址"></el-table-column>
      <el-table-column label="送达时间">
        <template slot-scope="scope">{{scope.row.deliveryTime |normalizeHMS}}</template>
      </el-table-column>
      <el-table-column prop="remarks" label="用户备注"></el-table-column>
      <el-table-column prop="orderAmount" label="订单金额"></el-table-column>
      <el-table-column prop="orderState" label="订单状态"></el-table-column>

      <el-table-column fixed="right" label="操作" width="100">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row,false)" type="text" size="small">查看</el-button>
          <el-button @click="handleClick(scope.row,true)" type="text" size="small">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-size="pageSize"
      layout="total, prev, pager, next, jumper"
      :total="total"
      class="mt20"
    ></el-pagination>
  </el-card>
</template>

<script>
import { getOrderList } from "@/api/order";
export default {
  data() {
    return {
      formData: {
        orderNo: "",
        consignee: "",
        phone: "",
        orderState: "",
        date: ""
      },

      tableData: [],
      h: 500,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      searchForm: {}
    };
  },
  created() {
    this.getData();
  },
  methods: {
    async getData(searchFrom = {}) {
      let res = await getOrderList({
        currentPage: this.currentPage,
        pageSize: this.pageSize,
        ...searchFrom
      });

      let { data, total } = res.data;
      this.tableData = data;
      this.total = total;
    },
    //查询
    handleSearch() {
      this.currentPage = 1;

      let date = JSON.stringify({ ...this.formData }.date);

      this.searchForm = { ...this.formData, date };

      this.getData({ ...this.searchForm });
    },
    //重置
    reset() {
      this.currentPage = 1;
      this.formData = {
        orderNo: "",
        consignee: "",
        phone: "",
        orderState: "",
        date: ""
      };
      this.searchForm = {};
      this.getData();
    },
    // 查看、编辑
    handleClick(row, isRevisable) {
      let data = { ...row, isRevisable };
      this.$router.push(
        `/order/order-update/${encodeURI(encodeURI(JSON.stringify(data)))}`
      );
    },
    //计算table宽度
    calcTableWidth() {
      this.h = document.body.clientWidth - 280;
    },
    //改变页码触发
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getData({ ...this.searchForm });
    }
  },
  mounted() {
    this.calcTableWidth();
    window.addEventListener("resize", this.calcTableWidth);
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.calcTableWidth);
  }
};
</script>

<style lang="scss" scoped>
</style>