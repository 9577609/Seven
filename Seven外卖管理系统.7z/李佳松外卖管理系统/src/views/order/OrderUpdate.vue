<template>
  <el-card>
    <div slot="header">
      <span>订单{{formData.isRevisable?'编辑':'查看'}}</span>
    </div>
    <el-form :model="formData" inline :disabled="!formData.isRevisable">
      <el-form-item label="订单号">
        <el-input v-model="formData.orderNo"></el-input>
      </el-form-item>
      <el-form-item label="下单时间">
        <el-date-picker v-model="formData.orderTime" type="datetime"></el-date-picker>
      </el-form-item>
      <el-form-item label="电话">
        <el-input v-model="formData.phone"></el-input>
      </el-form-item>
      <el-form-item label="收货人">
        <el-input v-model="formData.consignee"></el-input>
      </el-form-item>
      <el-form-item label="收货地址">
        <el-input v-model="formData.deliverAddress"></el-input>
      </el-form-item>
      <el-form-item label="送达时间">
        <el-date-picker v-model="formData.deliveryTime" type="datetime"></el-date-picker>
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="formData.remarks"></el-input>
      </el-form-item>
      <el-form-item label="订单金额">
        <el-input v-model="formData.orderAmount"></el-input>
      </el-form-item>
      <el-form-item label="订单状态">
        <el-select v-model="formData.orderState">
          <el-option value="已受理">已受理</el-option>
          <el-option value="派送中">派送中</el-option>
          <el-option value="已完成">已完成</el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <el-button
      :disabled="!formData.isRevisable"
      @click="updateData(true)"
      type="primary"
      size="small"
    >保存</el-button>
    <el-button @click="updateData(false)" type="info" size="small">取消</el-button>
  </el-card>
</template>

<script>
import { editOrder } from "@/api/order";
export default {
  data() {
    return {
      formData: {}
    };
  },
  methods: {
    //   更新数据
    async updateData(isUpdate) {
      if (!isUpdate) {
        this.$router.push("/order");
        return;
      }
      let res = await editOrder({ ...this.formData });
      let { code } = res.data;
      code === 0 && this.$router.push("/order");
    }
  },
  created() {
    this.formData = JSON.parse(decodeURI(this.$route.params.data));
  }
};
</script>

<style lang="scss" scoped>
::v-deep .el-form-item {
  width: 45%;
}
</style>