<template>
  <div class="login df jcc aic">
    <div class="form df fdc aic">
      <h3>系统登录</h3>
      <el-form
        ref="form"
        class="login-form"
        size="small"
        :model="formData"
        :rules="rules"
        status-icon
      >
        <el-form-item prop="userName">
          <el-input v-model="formData.userName" prefix-icon="iconfont icon-user"></el-input>
        </el-form-item>
        <el-form-item prop="userPwd">
          <el-input
            v-model="formData.userPwd"
            prefix-icon="iconfont icon-password"
            :type="flagPwd?'text':'password'"
          >
            <i
              slot="suffix"
              class="iconfont"
              :class="flagPwd?'icon-show':'icon-hide'"
              @click="flagPwd=!flagPwd"
            ></i>
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submit">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
// 工具函数导入
import { checkUserName, checkUserPwd } from "@/utils/utils";
// 登录Ajax函数导入
import { checkLogin } from "@/api/user";
import local from "@/utils/local";
export default {
  data() {
    return {
      formData: {
        userName: "",
        userPwd: ""
      },
      flagPwd: false,
      rules: {
        userName: [{ validator: checkUserName, trigger: "blur" }],
        userPwd: [{ validator: checkUserPwd, trigger: "blur" }]
      }
    };
  },
  methods: {
    submit() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          let res = await checkLogin({
            account: this.formData.userName,
            password: this.formData.userPwd
          });
          let { code, msg, token } = res.data;
          if (code === 0) {
            local.set("sl_tk", token);

            setTimeout(() => {
              this.$router.push("/home");
            }, 2000);
          }
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.login {
  width: 100%;
  height: 100%;
  background: url("../../assets/images/login_bg.jpg") no-repeat;
  background-size: 100% 100%;
  .form {
    .login-form {
      margin-top: 20px;
      width: 350px;
    }
    color: #fff;
    ::v-deep .el-input__inner {
      background-color: transparent;
      color: #fff;
    }
  }
}
.el-button {
  width: 100%;
}
</style>