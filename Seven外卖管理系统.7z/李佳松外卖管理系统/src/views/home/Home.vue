<template>
  <div class="home">
    <h-card v-if="dataList.length" :dataList="dataList">
      <template slot-scope="scope">
        <div class="item df">
          <div class="img-box f1 df aic jcc">
            <img class="img" :src="scope.row.imgUrl" alt />
          </div>
          <div class="info df fdc aic jcc f1">
            <div class="name">{{scope.row.name}}</div>
            <div class="num">{{scope.row.num | normalizeNum}}</div>
          </div>
        </div>
      </template>
    </h-card>

    <div class="chart" ref="chart"></div>
  </div>
</template>

<script>
import { getOrderTotalData } from "@/api/order";
import * as echarts from "echarts";
import HCard from "./HCard.vue";
export default {
  components: {
    HCard
  },
  data() {
    return {
      xData: "", //x轴数据
      orderData: "", //订单数据
      amountData: "", //金额数据
      totalOrder: "", //总订单
      totalAmount: "", //总销售额
      todayOrder: "", //今日订单
      totayAmount: "", //今日销售额
      dataList: [] //装卡片数据
    };
  },
  methods: {
    //获取数据
    async getData() {
      let res = await getOrderTotalData();
      let {
        totalOrder,
        totalAmount,
        todayOrder,
        totayAmount,
        xData,
        orderData,
        amountData
      } = res.data;
      this.dataList = [
        {
          name: "总订单",
          num: totalOrder,
          imgUrl: require("@/assets/images/h1.png")
        },
        {
          name: "总销售额",
          num: totalAmount,
          imgUrl: require("@/assets/images/h2.png")
        },
        {
          name: "今日订单",
          num: todayOrder,
          imgUrl: require("@/assets/images/h3.png")
        },
        {
          name: "今日销售额",
          num: totayAmount,
          imgUrl: require("@/assets/images/h4.png")
        }
      ];
      this.renderChart(xData, orderData, amountData);
    },
    //渲染echart图表
    renderChart(xData, orderData, amountData) {
      this.myChart = echarts.init(this.$refs.chart);
      let option = {
        title: {
          text: "数据统计",
          top: 15,
          left: 15
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross"
          }
        },
        legend: {
          top: 15
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        toolbox: {
          feature: {
            saveAsImage: {}
          }
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: xData
        },
        yAxis: {
          type: "value"
        },
        series: [
          {
            name: "订单数据",
            type: "line",
            data: orderData
          },
          {
            name: "金额数据",
            type: "line",
            data: amountData
          }
        ]
      };

      this.myChart.setOption(option);
      window.addEventListener("resize", this.myChart.resize);
    }
  },
  mounted() {
    this.getData();
  }
};
</script>
<style lang="scss" scoped>
.chart {
  margin-top: 50px;
  width: 100%;
  height: 300px;
  background-color: #fff;
}
.br10 {
  border-radius: 10px;
}
.div {
  width: 100px;
  height: 100px;
  background: saddlebrown;
  @extend .br10;
}
.item {
  background: white;
  width: 24%;
  height: 100px;
  .img {
    width: 40px;
  }
}
</style>