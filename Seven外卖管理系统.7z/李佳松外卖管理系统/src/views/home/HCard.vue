<template>
  <div class="h-card df jcsb">
    <slot v-for="item in dataList" :row="item"></slot>
  </div>
</template>

<script>
export default {
  props: ["dataList"]
};
</script>

<style lang="scss" scoped>
</style>