<template>
  <el-card class="shop">
    <div slot="header" class="df jcsb aic">
      <span>店铺管理</span>
      <el-button size="mini" @click="isEdit=!isEdit" v-if="!isEdit">编辑</el-button>
      <el-button v-else @click="isEdit=!isEdit;submit()" type="success" size="mini">保存</el-button>
    </div>

    <div class="content">
      <el-form :disabled="!isEdit" :model="formData" size="small" label-width="80px" class="form">
        <el-form-item label="店铺名称">
          <el-input type="text" v-model="formData.name"></el-input>
        </el-form-item>
        <el-form-item label="店铺公告">
          <el-input type="textarea" :rows="8" placeholder="请输入内容" v-model="formData.bulletin"></el-input>
        </el-form-item>
        <el-form-item label="店铺头像">
          <el-upload
            class="avatar-uploader"
            :action="'/shop/upload'"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload"
          >
            <img v-if="formData.avatar" :src="formData.avatar" class="avatar" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="店铺图片">
          <el-upload
            action="/shop/upload"
            list-type="picture-card"
            :on-preview="handlePictureCardPreview"
            :fileList="formData.pics"
            :on-remove="handleRemove"
            :on-success="handleShopSuccess"
            :before-upload="beforeAvatarUpload"
          >
            <i class="el-icon-plus"></i>
          </el-upload>
          <el-dialog :visible.sync="dialogVisible">
            <img width="100%" :src="dialogImageUrl" alt />
          </el-dialog>
        </el-form-item>
        <el-form-item label="配送费">
          <el-input-number v-model="formData.deliveryPrice" :min="1" :max="1000"></el-input-number>
        </el-form-item>
        <el-form-item label="配送时间">
          <el-input-number v-model="formData.deliveryTime" :min="1" :max="100"></el-input-number>
        </el-form-item>
        <el-form-item label="配送描述">
          <el-input type="text" v-model="formData.description"></el-input>
        </el-form-item>
        <el-form-item label="店铺评分">
          <el-rate v-model="formData.score"></el-rate>
        </el-form-item>
        <el-form-item label="销量">
          <el-input-number v-model="formData.sellCount" :min="1" :max="10000"></el-input-number>
        </el-form-item>
        <el-form-item label="活动">
          <el-checkbox-group v-model="formData.supports">
            <el-checkbox label="在线支付满28减5"></el-checkbox>
            <el-checkbox label="VC无限橙果汁全场8折"></el-checkbox>
            <el-checkbox label="单人精彩套餐"></el-checkbox>
            <el-checkbox label="特价饮品8折抢购"></el-checkbox>
            <el-checkbox label="单人特色套餐"></el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="营业时间">
          <el-date-picker
            v-model="formData.date"
            type="datetimerange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd HH:mm:ss"
            format="HH:mm:ss"
          ></el-date-picker>
        </el-form-item>
      </el-form>
    </div>
  </el-card>
</template>

<script>
import { getShopInfo, editShop } from "@/api/shop";
export default {
  data() {
    return {
      isEdit: false, //是否可编辑
      formData: {
        //表单数据
        id: "", //id
        name: "", //店铺名称
        bulletin: "", //公告
        avatar: "", //店铺头像
        deliveryPrice: 1, //配送费
        deliveryTime: 1, //送达时间
        description: "", //描述
        score: 1, //评分
        sellCount: 1, //销量
        supports: [], //活动
        pics: [], //店铺图片
        date: [], //营业时间
        minPrice: 1 //起送价格
      },
      dialogImageUrl: "",
      dialogVisible: false,
      fileList: [
        {
          name: "food.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100"
        },
        {
          name: "food2.jpeg",
          url:
            "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100"
        }
      ]
    };
  },
  created() {
    this.getData();
  },
  methods: {
    async getData() {
      let res = await getShopInfo();
      let { data } = res.data;
      data.pics = data.pics.map(v => {
        return {
          name: v,
          url: "/upload/shop/" + v
        };
      });

      data.avatar = "/upload/shop/" + data.avatar;
      this.formData = data;
    },
    //保存
    async submit() {
      let formData = { ...this.formData };
      let avatar = formData.avatar.substr(formData.avatar.lastIndexOf("/") + 1);
      let pics = formData.pics.map(v => v.name);

      let res = await editShop({ ...formData, pics, avatar });
      console.log("res.data :>> ", res.data);
    },
    //上传成功回调
    handleAvatarSuccess(res) {
      let { code, msg, imgUrl } = res;
      if (code === 0) {
        this.$message({ type: "success", message: msg });
        this.formData.avatar = imgUrl;
      }
    },
    //上传店铺图片成功回调
    handleShopSuccess(res) {
      let imgUrl = res.imgUrl;
      let data = {
        name: imgUrl.substr(imgUrl.lastIndexOf("/") + 1),
        url: imgUrl
      };
      this.formData.pics.push(data);
    },
    //限制图片格式
    beforeAvatarUpload(file) {
      const isJPG_PNG = /(jpeg|png)/.test(file.type);
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG_PNG) {
        this.$message.error("上传头像图片只能是 JPG 格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG_PNG && isLt2M;
    },
    handleRemove(file) {
      this.formData.pics = this.formData.pics.filter(v => v.name !== file.name);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    }
  }
};
</script>

<style lang="scss" scoped>
.form {
  width: 400px;
}
.avatar-uploader ::v-deep.el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  line-height: 100px;
  text-align: center;
}
.avatar {
  width: 100px;
  height: 100px;
  display: block;
}
</style>