<template>
  <el-card>
    <div slot="header">
      <span>管理员中心</span>
    </div>
    <span>管理员ID: {{userInfo.id}}</span>
    <el-divider></el-divider>
    <span>账号: {{userInfo.account}}</span>
    <el-divider></el-divider>
    <span>用户组: {{userInfo.userGroup}}</span>
    <el-divider></el-divider>
    <span>创建时间: {{userInfo.ctime|normalizeYMD}}</span>
    <el-divider></el-divider>
    <span class="df">
      <span>管理员头像:</span>
      <el-upload
        class="avatar-uploader"
        :action="'/users/avatar_upload'"
        :show-file-list="false"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload"
      >
        <img v-if="userInfo.imgUrl" :src="userInfo.imgUrl" class="avatar" />
        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
      </el-upload>
    </span>
    <el-button
      @click="uploadAvatar"
      size="small"
      type="primary"
      style="margin-left:100px;margin-top:10px"
    >确认上传</el-button>
  </el-card>
</template>

<script>
import { avatarEdit } from "@/api/user";
import local from "@/utils/local";
export default {
  data() {
    return {
      userInfo: {
        account: "",
        ctime: "",
        id: 0,
        imgUrl: "",
        userGroup: ""
      }
    };
  },
  created() {
    this.userInfo = local.get("userInfo");
  },

  methods: {
    async uploadAvatar() {
      let res = await avatarEdit({
        imgUrl: this.userInfo.imgUrl.substr(
          this.userInfo.imgUrl.lastIndexOf("/") + 1
        )
      });
      let { code, msg } = res.data;
      code === 0 && this.$bus.$emit("uploadAvatar");
    },
    handleAvatarSuccess(res) {
      let { code, msg, imgUrl } = res;
      code === 0 && (this.userInfo.imgUrl = imgUrl);
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG 格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    }
  }
};
</script>

<style lang="scss" scoped>
.avatar-uploader ::v-deep.el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  margin-left: 20px;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 90px;
  height: 90px;
  line-height: 90px;
  text-align: center;
}
.avatar {
  width: 90px;
  height: 90px;
  display: block;
}
</style>