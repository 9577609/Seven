<template>
  <el-card>
    <div slot="header">
      <span>修改密码</span>
    </div>
    <div class="content">
      <el-form :model="form" :rules="rules" size="small" status-icon ref="form" label-width="80px">
        <el-form-item label="原密码" prop="oldPwd">
          <el-input v-model="form.oldPwd" type="password"></el-input>
        </el-form-item>
        <el-form-item label="新密码" prop="newPwd">
          <el-input v-model="form.newPwd" type="password"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPwd">
          <el-input v-model="form.confirmPwd" type="password"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submit">确认</el-button>
          <el-button @click="reset">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-card>
</template>

<script>
import { checkOldPwd, editPwd } from "@/api/user";
export default {
  data() {
    // 验证密码
    const checkPwd = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请填写密码"));
      } else if (!/^[a-zA-Z0-9_-]{6,12}$/.test(value)) {
        callback(new Error("密码6至12位"));
      } else {
        callback();
      }
    };
    //验证新密码
    const checkNewPwd = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请填写密码"));
      } else if (value === this.form.oldPwd) {
        callback(new Error("新旧密码不能相同"));
      } else if (!/^[a-zA-Z0-9_-]{6,12}$/.test(value)) {
        callback(new Error("密码6至12位"));
      } else {
        if (this.form.confirmPwd !== "") {
          this.$refs.form.validateField("confirmPwd");
        }
        callback();
      }
    };
    //验证再次输入密码
    const checkConfirmPwd = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请填写密码"));
      } else if (value !== this.form.newPwd) {
        callback(new Error("密码不一致"));
      } else {
        callback();
      }
    };
    return {
      form: {
        oldPwd: "",
        newPwd: "",
        confirmPwd: ""
      },
      rules: {
        oldPwd: [{ validator: checkPwd, trigger: "blur" }],
        newPwd: [{ validator: checkNewPwd, trigger: "blur" }],
        confirmPwd: [{ validator: checkConfirmPwd, trigger: "blur" }]
      }
    };
  },
  methods: {
    submit() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          let res1 = await checkOldPwd({
            oldPwd: this.form.oldPwd
          });
          let { code, msg } = res1.data;
          if (code === "11") {
            this.$message.error(msg);
          } else {
            let res2 = await editPwd({
              newPwd: this.form.newPwd
            });
            let { code, msg } = res2.data;
            if (code === 0) {
              setTimeout(() => {
                this.$router.push("/login");
              }, 1000);
            }
          }
        }
      });
    },
    reset() {
      this.$refs.form.resetFields();
    }
  }
};
</script>

<style lang="scss" scoped>
::v-deep .el-input {
  width: 197px;
}
</style>