<template>
  <el-card>
    <div slot="header">
      <span>添加账号</span>
    </div>
    <el-form :model="form" status-icon :rules="rules" ref="form" label-width="80px" size="small">
      <el-form-item label="账号" prop="userName">
        <el-input type="text" v-model="form.userName" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="userPwd">
        <el-input type="password" v-model="form.userPwd" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="用户组" prop="userGroup">
        <el-select v-model="form.userGroup" placeholder="请选择用户组">
          <el-option label="普通管理员" value="普通管理员"></el-option>
          <el-option label="超级管理员" value="超级管理员"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submit">确认</el-button>
        <el-button @click="reset">重置</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
import { usersAdd } from "@/api/user";
export default {
  data() {
    return {
      form: {
        userName: "",
        userPwd: "",
        userGroup: ["普通管理员", "超级管理员"]
      },
      rules: {
        userName: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { min: 3, max: 12, message: "长度在 3 到 12 个字符", trigger: "blur" }
        ],
        userPwd: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, max: 12, message: "长度在 6 到 12 个字符", trigger: "blur" }
        ],
        userGroup: [{ required: true, message: "请选择分组", trigger: "blur" }]
      }
    };
  },
  methods: {
    submit() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          let res = await usersAdd({
            account: this.form.userName,
            password: this.form.userPwd,
            userGroup: this.form.userGroup
          });
          let { code, msg } = res.data;
          code === 0 && this.$router.push("/account/account-list");
        }
      });
    },
    reset() {
      this.$refs.form.resetFields();
    }
  }
};
</script>

<style lang="scss" scoped>
::v-deep .el-input {
  width: 197px;
}
</style>