<template>
  <el-card>
    <div slot="header">
      <span>账号列表</span>
    </div>
    <el-table :data="tableData" style="width: 100%" ref="table" @selection-change="selectChange">
      <el-table-column type="selection"></el-table-column>
      <el-table-column label="账号" prop="account"></el-table-column>
      <el-table-column prop="userGroup" label="用户组"></el-table-column>
      <el-table-column label="创建时间">
        <template slot-scope="scope">{{scope.row.ctime|normalizeYMD}}</template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
          <el-popconfirm title="确定删除吗？" @confirm="handleDelete(scope.row.id)">
            <el-button size="mini" slot="reference" type="danger">删除</el-button>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="mt20"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[3,5]"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    ></el-pagination>
    <div class="mt20">
      <el-popover placement="bottom" width="160" v-model="visible">
        <p>确定删除吗？</p>
        <div style="text-align: right; margin: 0">
          <el-button size="mini" type="text" @click="visible = false">取消</el-button>
          <el-button type="primary" size="mini" @click="batchdel">确定</el-button>
        </div>
        <el-button style="margin-right:10px" type="danger" slot="reference" size="small">批量删除</el-button>
      </el-popover>
      <el-button size="small" @click="cancelCheck">取消选择</el-button>
    </div>

    <!-- 编辑用户 -->
    <el-dialog title="编辑用户" :visible.sync="dialogFormVisible">
      <el-form :model="formEdit" size="small">
        <el-form-item label="账号" label-width="80px">
          <el-input v-model="formEdit.account" :style="{width:'186px'}"></el-input>
        </el-form-item>
        <el-form-item label="用户组" label-width="80px">
          <el-select v-model="formEdit.userGroup">
            <el-option value="超级管理员"></el-option>
            <el-option value="普通管理员"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="updateUser">确 定</el-button>
      </div>
    </el-dialog>
  </el-card>
</template>

<script>
import { getUsersList, usersDel, editAccount, usersBatchdel } from "@/api/user";
export default {
  data() {
    return {
      currentPage: 1,
      pageSize: 3,
      total: 0,
      tableData: [],
      dialogFormVisible: false,
      visible: false,
      ids: [],
      formEdit: {
        id: "",
        account: "",
        userGroup: ""
      }
    };
  },
  methods: {
    // 获取数据
    async getData() {
      let res = await getUsersList({
        currentPage: this.currentPage,
        pageSize: this.pageSize
      });
      let { total, data } = res.data;
      this.total = total;
      this.tableData = [...data];
      if (data.length === 0 && this.currentPage !== 1) {
        this.currentPage--;
        this.getData();
      }
    },
    // 修改当前页显示总条数
    handleSizeChange(val) {
      this.pageSize = val;
      this.getData();
    },
    // 修改当前页码
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getData();
    },
    // 编辑用户
    handleEdit(val) {
      this.dialogFormVisible = true;
      this.formEdit.account = val.account;
      this.formEdit.userGroup = val.userGroup;
      this.formEdit.id = val.id;
    },
    // 确认修改用户
    async updateUser() {
      let res = await editAccount({
        id: this.formEdit.id,
        account: this.formEdit.account,
        userGroup: this.formEdit.userGroup
      });
      let { code, msg } = res.data;
      if (code === 0) {
        Object.keys(this.formEdit).forEach(v => (this.formEdit[v] = ""));
        this.dialogFormVisible = false;
        this.getData();
      }
    },
    // 删除用户
    async handleDelete(id) {
      let res = await usersDel({
        id
      });
      let { code, msg } = res.data;
      code === 0 && this.getData();
    },
    // 取消选择
    cancelCheck() {
      this.$refs.table.clearSelection();
    },
    // 选项切换
    selectChange(val) {
      this.ids = JSON.stringify(val.map(v => v.id));
    },
    // 批量删除
    async batchdel() {
      let res = await usersBatchdel({ ids: this.ids });
      let { code, msg } = res.data;
      code === 0 && this.getData();

      this.visible = false;
    }
  },

  created() {
    this.getData();
  }
};
</script>

<style lang="scss" scoped>
</style>