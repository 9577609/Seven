<template>
  <div class="total-order">
    <!-- 查询 -->
    <div class="search df aic">
      <span>查询范围</span>
      <!-- value-format 值格式 -->
      <!-- format 显示格式 -->
      <el-date-picker
        size="small"
        v-model="date"
        type="datetimerange"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        value-format="yyyy-MM-dd HH:mm:ss"
        format="yyyy-MM-dd HH:mm:ss"
      ></el-date-picker>
      <!-- 查询按钮 -->
      <el-button type="primary" @click="getData" size="small">查询</el-button>
    </div>
    <!-- 图表 -->
    <div class="my-chart" ref="chart"></div>
  </div>
</template>

<script>
import { getOrderTotal } from "@/api/order";
import { normalizeYMDhms } from "@/filters";
//引入echats
import * as echarts from "echarts";
export default {
  data() {
    return {
      date: [] //日期选择
    };
  },
  //渲染图表 mounted生命周期好一些
  mounted() {
    this.getData();
  },
  methods: {
    async getData() {
      let res = await getOrderTotal({ date: JSON.stringify(this.date) });
      //解构数据
      let { data } = res.data;

      let xData = data.map(v => normalizeYMDhms(v.orderTime));
      let yData = data.map(v => v.orderAmount);
      //调取渲染函数
      this.renderChart(xData, yData);
    },
    //渲染echart图表
    renderChart(xData, yData) {
      // 基于准备好的dom，初始化echarts实例
      this.myChart = echarts.init(this.$refs.chart);
      //配置图表
      let option = {
        //标题
        title: {
          text: "订单统计",
          top: 15,
          left: 15
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross"
          }
        },
        //
        legend: {
          top: 15
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        toolbox: {
          feature: {
            saveAsImage: {}
          }
        },
        //x轴
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: xData
        },
        //y轴
        yAxis: {
          type: "value"
        },
        // 核心数据
        series: [
          {
            name: "订单数据",
            type: "line",
            data: yData,
            smooth: true
          }
        ]
      };

      // 绘制图表
      this.myChart.setOption(option);
      //异步问题 当创建实例之后再执行
      window.addEventListener("resize", this.myChart.resize);
    }
  },
  //销毁前 销毁全局挂载的东西
  beforeDestroy() {
    window.removeEventListener("resize", this.myChart.resize);
  }
};
</script>

<style lang="scss" scoped>
.el-date-editor {
  width: 384px;
  margin: 0 10px;
}
.my-chart {
  margin-top: 50px;
  width: 100%;
  height: 300px;
  background-color: #fff;
}
</style>