<template>
  <el-card>
    <div slot="header">
      <span>商品列表</span>
    </div>
    <el-table :data="tableData">
      <el-table-column type="expand">
        <template slot-scope="scope">
          <el-form label-position="left" inline class="demo-table-expand">
            <el-form-item label="商品ID">
              <span>{{ scope.row.id }}</span>
            </el-form-item>
            <el-form-item label="商品名称">
              <span>{{ scope.row.name }}</span>
            </el-form-item>
            <el-form-item label="所属分类">
              <span>{{ scope.row.category }}</span>
            </el-form-item>
            <el-form-item label="商品价格">
              <span>{{ scope.row.price }}</span>
            </el-form-item>
            <el-form-item label="商品图片">
              <img style="width:70px;height:70px" :src="scope.row.imgUrl" />
            </el-form-item>
            <el-form-item label="创建时间">
              <span>{{ scope.row.ctime|normalizeYMDhms}}</span>
            </el-form-item>
            <el-form-item label="商品评价">
              <span>{{ scope.row.rating }}</span>
            </el-form-item>
            <el-form-item label="商品销量">
              <span>{{ scope.row.sellCount }}</span>
            </el-form-item>
            <el-form-item label="商品描述">
              <span>{{ scope.row.goodsDesc }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="商品名称">
        <template slot-scope="scope">
          <span v-if="!scope.row.isEdit">{{scope.row.name}}</span>
          <el-input v-else size="mini" type="text" v-model="scope.row.name"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="所属分类">
        <template slot-scope="scope">
          <span v-if="!scope.row.isEdit">{{scope.row.category}}</span>
          <el-select size="mini" v-else v-model="scope.row.category">
            <el-option
              :label="item.cateName"
              :value="item.cateName"
              v-for="item in cateData"
              :key="item.cateName"
            ></el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column label="商品价格">
        <template slot-scope="scope">
          <span v-if="!scope.row.isEdit">{{scope.row.price}}</span>
          <el-input v-else size="mini" type="text" v-model="scope.row.price"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="商品图片">
        <template slot-scope="scope">
          <img v-if="!scope.row.isEdit" style="width:140px;height:140px" :src="scope.row.imgUrl" />
          <el-upload
            v-else
            class="img-uploader"
            :on-success="(value)=>handleImgSuccess(scope.row,value)"
            :action="'/goods/goods_img_upload'"
            :show-file-list="false"
            :before-upload="beforeImgUpload"
          >
            <img v-if="scope.row.imgUrl" :src="scope.row.imgUrl" style="width:140px;height:140px" />
            <i v-else class="el-icon-plus img-uploader-icon"></i>
          </el-upload>
        </template>
      </el-table-column>
      <el-table-column label="商品描述">
        <template slot-scope="scope">
          <span v-if="!scope.row.isEdit">{{scope.row.goodsDesc}}</span>
          <el-input v-else size="mini" type="text" v-model="scope.row.goodsDesc"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="160">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="handleEdit(scope.row)"
            :type="scope.row.isEdit?'success':''"
          >{{scope.row.isEdit?'完成':'编辑'}}</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-size="pageSize"
      layout="total, prev, pager, next, jumper"
      :total="total"
      background
      class="mt20"
    ></el-pagination>
  </el-card>
</template>

<script>
import { getGoodsList, goodsEdit, goodsDel, getCategories } from "@/api/goods";
export default {
  data() {
    return {
      tableData: [],
      currentPage: 1,
      pageSize: 5,
      total: 0,
      cateData: []
    };
  },
  methods: {
    // 获取分类数据
    async getCateDate() {
      let res = await getCategories();
      this.cateData = [...res.data];
    },
    //获取数据
    async getData() {
      let res = await getGoodsList({
        currentPage: this.currentPage,
        pageSize: this.pageSize
      });
      let { data, total } = res.data;
      data = data.map(v => {
        v.isEdit = false;
        return v;
      });
      this.tableData = data;
      this.total = total;

      if (data.length === 0 && this.currentPage !== 1) {
        this.currentPage--;
        this.getData();
      }
    },
    //编辑
    async handleEdit(row) {
      row.isEdit = !row.isEdit;
      if (!row.isEdit) {
        let data = { ...row };
        data.imgUrl = data.imgUrl.substr(data.imgUrl.lastIndexOf("/") + 1);
        let res = await goodsEdit(data);
      }
    },
    //删除
    handleDelete(row) {
      let { id } = row;
      this.$confirm("是否删除该商品?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          let res = await goodsDel({ id });
          let { code } = res.data;
          code === 0 && this.getData();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    //当前页改变
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getData();
    },

    handleImgSuccess(row, res) {
      let { code, imgUrl } = res;
      code === 0 && (row.imgUrl = imgUrl);
    },
    beforeImgUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG 格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    }
  },
  created() {
    this.getCateDate();
    this.getData();
  }
};
</script>

<style lang="scss" scoped>
.img-uploader ::v-deep.el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.img-uploader .el-upload:hover {
  border-color: #409eff;
}
.img-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 120px;
  height: 120px;
  line-height: 120px;
  text-align: center;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>