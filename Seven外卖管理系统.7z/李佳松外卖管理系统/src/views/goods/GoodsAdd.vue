<template>
  <el-card>
    <div slot="header">
      <span>商品添加</span>
    </div>
    <el-form label-width="80px" size="small" :model="form">
      <el-form-item label="商品名称">
        <el-input style="width:250px" type="text" placeholder="商品名称" v-model="form.name"></el-input>
      </el-form-item>
      <el-form-item label="商品分类">
        <el-select placeholder="请选择商品分类" v-model="form.cate">
          <el-option
            :label="item.cateName"
            :value="item.cateName"
            v-for="item in cateData"
            :key="item.cateName"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="商品价格">
        <el-input-number v-model="form.price" :min="0" :max="100"></el-input-number>
      </el-form-item>
      <el-form-item label="商品图片">
        <el-upload
          class="img-uploader"
          :action="'/goods/goods_img_upload'"
          :show-file-list="false"
          :on-success="handleImgSuccess"
          :before-upload="beforeImgUpload"
        >
          <img v-if="form.imgUrl" :src="form.imgUrl" class="img" />
          <i v-else class="el-icon-plus img-uploader-icon"></i>
        </el-upload>
      </el-form-item>
      <el-form-item label="商品描述">
        <el-input type="textarea" style="width:250px" :rows="2" v-model="form.desc"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="addGoods">添加商品</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
import { getCategories, goodsAdd } from "@/api/goods";
export default {
  data() {
    return {
      cateData: [],
      form: {
        name: "",
        cate: "",
        price: "",
        imgUrl: "",
        desc: ""
      }
    };
  },
  methods: {
    // 获取商品分类数据
    async getData() {
      let res = await getCategories();
      this.cateData = [...res.data];
    },
    // 添加商品
    async addGoods() {
      let res = await goodsAdd({
        name: this.form.name,
        category: this.form.cate,
        price: this.form.price,
        imgUrl: this.form.imgUrl.substr(this.form.imgUrl.lastIndexOf("/") + 1),
        goodsDesc: this.form.desc
      });
      let { code } = res.data;
      code === 0 && this.$router.push("/goods/goods-list");
    },
    handleImgSuccess(res) {
      let { code, msg, imgUrl } = res;
      code === 0 && (this.form.imgUrl = imgUrl);
    },
    beforeImgUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG 格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    }
  },
  created() {
    this.getData();
  }
};
</script>

<style lang="scss" scoped>
.img-uploader ::v-deep.el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.img-uploader .el-upload:hover {
  border-color: #409eff;
}
.img-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 120px;
  height: 120px;
  line-height: 120px;
  text-align: center;
}
.img {
  width: 120px;
  height: 120px;
  display: block;
}
</style>