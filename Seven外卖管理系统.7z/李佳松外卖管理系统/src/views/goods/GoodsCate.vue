<template>
  <el-card>
    <div slot="header" class="df aic jcsb">
      <span>商品分类</span>
      <el-button type="primary" size="mini" @click="dialogFormVisible=true">添加分类</el-button>
    </div>
    <div class="content">
      <el-table :data="tableData">
        <el-table-column type="index" label="序号"></el-table-column>
        <el-table-column label="分类名称">
          <template slot-scope="scope">
            <span v-if="!scope.row.isEdit">{{scope.row.cateName}}</span>
            <el-input v-else size="mini" type="text" v-model="scope.row.cateName"></el-input>
          </template>
        </el-table-column>

        <el-table-column label="是否启用">
          <template slot-scope="scope">
            <el-switch
              v-model="scope.row.state"
              active-color="#13ce66"
              inactive-color="#ff4949"
              :disabled="!scope.row.isEdit"
            ></el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button
              size="mini"
              @click="handleEdit(scope.row)"
              :type="scope.row.isEdit?'success':''"
            >{{scope.row.isEdit?'完成':'编辑'}}</el-button>
            <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-size="pageSize"
        layout="total, prev, pager, next, jumper"
        :total="total"
        background
        class="mt20"
      ></el-pagination>
    </div>

    <el-dialog title="添加分类" :visible.sync="dialogFormVisible">
      <el-form :model="formData" size="small" label-width="80px">
        <el-form-item label="分类名称">
          <el-input style="width:200px" type="text" v-model="formData.cateName"></el-input>
        </el-form-item>
        <el-form-item label="是否启用">
          <el-switch v-model="formData.state" active-color="#13ce66" inactive-color="#ff4949"></el-switch>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addGoodsCate();dialogFormVisible = false">确 定</el-button>
      </div>
    </el-dialog>
  </el-card>
</template>

<script>
import { getCateList, editCate, delCate, addCate } from "@/api/goods";

export default {
  data() {
    return {
      tableData: [],
      currentPage: 1,
      pageSize: 5,
      total: 0,
      dialogFormVisible: false,
      formData: {
        cateName: "",
        state: false
      }
    };
  },
  methods: {
    //获取数据
    async getData() {
      let res = await getCateList({
        currentPage: this.currentPage,
        pageSize: this.pageSize
      });
      let { data, total } = res.data;
      data = data.map(v => {
        v.state = v.state === 1 ? true : false;
        v.isEdit = false;
        return v;
      });
      this.tableData = data;
      this.total = total;
      if (data.length === 0 && this.currentPage !== 1) {
        this.currentPage--;
        this.getData();
      }
    },
    //编辑
    async handleEdit(row) {
      row.isEdit = !row.isEdit;
      if (!row.isEdit) {
        let { id, cateName, state } = row;
        state = state ? 1 : 0;
        let res = await editCate({ id, cateName, state });
      }
    },
    //删除
    handleDelete(row) {
      let { id } = row;
      this.$confirm("是否删除分类?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(async () => {
          let res = await delCate({ id });
          let { code } = res.data;
          code === 0 && this.getData();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    //当前页改变
    handleCurrentChange(val) {
      this.currentPage = val;
      this.getData();
    },
    // 添加分类
    async addGoodsCate() {
      let res = await addCate({
        cateName: this.formData.cateName,
        state: this.formData.state ? 1 : 0
      });
      let { code } = res.data;
      code === 0 && this.getData();
    }
  },
  created() {
    this.getData();
  }
};
</script>

<style lang="scss" scoped>
</style>