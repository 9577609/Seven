<template>
  <div class="layout df">
    <!-- 左侧导航 -->
    <left-nav class="fn"></left-nav>
    <!-- 右侧主体 -->
    <div class="main f1 df fdc">
      <!-- 右侧头部 -->
      <right-header class="fn"></right-header>
      <!-- 右侧主体 -->
      <div class="content f1 ofs">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import LeftNav from "./LeftNav.vue";
import RightHeader from "./RightHeader.vue";

export default {
  components: {
    LeftNav,
    RightHeader
  }
};
</script>

<style lang="scss" scoped>
.layout {
  height: 100%;
  .main {
    .content {
      background-color: #f0f2f5;
      padding: 20px;
    }
  }
}
</style>