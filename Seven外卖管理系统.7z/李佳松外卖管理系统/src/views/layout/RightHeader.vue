<template>
  <div class="df aic right-header">
    <el-col :span="12">
      <div class="left-path">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item
            v-for="item in clacPath"
            :key="item.path"
            :to="{ path: item.path }"
          >{{item.address}}</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
    </el-col>
    <el-col :span="12">
      <div class="right-user df aic">
        <div class="info">
          欢迎你!
          <el-dropdown @command="pushPath">
            <span class="el-dropdown-link">
              {{account}}
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="center">个人中心</el-dropdown-item>
              <el-dropdown-item command="login">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        <el-avatar :src="imgUrl"></el-avatar>
      </div>
    </el-col>
  </div>
</template>

<script>
import { getUserInfo } from "@/api/user";
import local from "@/utils/local";
export default {
  data() {
    return {
      account: "",
      imgUrl: ""
    };
  },
  methods: {
    async getData() {
      let res = await getUserInfo();
      local.set("userInfo", res.data);
      let { account, imgUrl } = res.data;
      this.account = account;
      this.imgUrl = imgUrl;
    },
    pushPath(val) {
      switch (val) {
        case "center":
          this.$router.push("/account/account-center");
          break;
        case "login":
          this.$alert("确认退出吗？", "提示信息", {
            confirmButtonText: "确定",
            callback: action => {
              if (action === "confirm") {
                local.clear();
                this.$message({
                  message: "退出成功",
                  type: "success"
                });
                this.$router.push("/login");
              }
            }
          });

          break;
        default:
          break;
      }
    }
  },
  created() {
    this.getData();
    this.$bus.$on("uploadAvatar", () => {
      this.getData();
    });
  },
  computed: {
    clacPath() {
      return [
        { path: "/", address: "首页" },
        ...this.$route.matched
          .filter(v => v.meta && v.meta.path)
          .map(v => v.meta)
      ];
    }
  }
};
</script>

<style lang="scss" scoped>
.right-header {
  height: 50px;
  padding: 0 20px;
  .right-user {
    justify-content: flex-end;
    .info {
      margin-right: 10px;
    }
  }
}
.el-dropdown-link {
  cursor: pointer;
  color: #409eff;
}
.el-icon-arrow-down {
  font-size: 12px;
}
</style>