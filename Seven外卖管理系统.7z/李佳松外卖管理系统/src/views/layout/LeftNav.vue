<template>
  <div class="left-menu">
    <div class="logo df aic jcc">
      <i class="iconfont icon-logo"></i>
      <span slot="title">后台管理</span>
    </div>
    <el-menu
      class="left-menu"
      text-color="#fff"
      active-text-color="#3578bc"
      background-color="#304156"
      unique-opened
      router
      :default-active="$route.path"
    >
      <el-menu-item index="/home">
        <i class="iconfont icon-home"></i>
        <span slot="title">后台首页</span>
      </el-menu-item>

      <el-menu-item index="/order">
        <i class="iconfont icon-order"></i>
        <span slot="title">订单管理</span>
      </el-menu-item>

      <el-submenu index="1">
        <template slot="title">
          <i class="iconfont icon-product"></i>
          <span>商品管理</span>
        </template>
        <el-menu-item index="/goods/goods-list">商品列表</el-menu-item>
        <el-menu-item index="/goods/goods-add">商品添加</el-menu-item>
        <el-menu-item index="/goods/goods-cate">商品分类</el-menu-item>
      </el-submenu>

      <el-menu-item index="/shop">
        <i class="iconfont icon-shop"></i>
        <span slot="title">店铺管理</span>
      </el-menu-item>

      <el-submenu index="2">
        <template slot="title">
          <i class="iconfont icon-account"></i>
          <span>账号管理</span>
        </template>
        <el-menu-item index="/account/account-list">账号列表</el-menu-item>
        <el-menu-item index="/account/account-add">添加账号</el-menu-item>
        <el-menu-item index="/account/update-pwd">修改密码</el-menu-item>
        <el-menu-item index="/account/account-center">账号中心</el-menu-item>
      </el-submenu>

      <el-submenu index="3">
        <template slot="title">
          <i class="iconfont icon-data"></i>
          <span>销售统计</span>
        </template>
        <el-menu-item index="/total/total-goods">商品统计</el-menu-item>
        <el-menu-item index="/total/total-order">订单统计</el-menu-item>
      </el-submenu>
    </el-menu>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.left-menu {
  width: 200px;
  background-color: #304156;
  .iconfont {
    color: #fff;
    font-size: 24px;
    margin-right: 10px;
  }
  .logo {
    height: 80px;
    color: rgb(61, 139, 221);
    font-size: 22px;
    .iconfont {
      font-size: 60px;
      color: rgb(61, 139, 221);
    }
  }
}
.el-menu-item {
  &:hover {
    background-color: darken(#304156, 5%) !important;
  }
}
.is-active {
  background-color: darken(#304156, 20%) !important;
}
.el-menu {
  border-right: none;
}
.el-menu--inline {
  .el-menu-item {
    &:hover {
      background-color: darken(#304156, 5%) !important;
    }
    background-color: darken(#304156, 10%) !important;
  }
  .is-active {
    background-color: darken(#304156, 20%) !important;
  }
}
</style>