// 验证用户名
export const checkUserName = (rule, value, callback) => {
    if (value === "") {
        callback(new Error("请填写用户名"));
    } else if (!/^[a-zA-Z0-9_-]{3,12}$/.test(value)) {
        callback(new Error("密用户名3-12位"));
    } else {
        callback();
    }
};
// 验证密码
export const checkUserPwd = (rule, value, callback) => {
    if (value === "") {
        callback(new Error("请填写密码"));
    } else if (!/^[a-zA-Z0-9_-]{6,12}$/.test(value)) {
        callback(new Error("密码6-12位"));
    } else {
        callback();
    }
};