import axios from 'axios'
import local from '@/utils/local'
import { Message } from 'element-ui';
import router from '@/router';
axios.defaults.baseURL = ''
axios.defaults.timeout = 10000;

axios.interceptors.request.use(config => {
    const token = local.get('sl_tk')
    config.headers.authorization = token
    return config
}, err => {
    return Promise.reject(err)
})

axios.interceptors.response.use(response => {
    let { code, msg } = response.data

    switch (code) {
        case 0:
            Message({ type: 'success', message: msg })
            break;
        case 1:
            Message.error(msg)
            break;
        case 5001:
            Message.error(msg)
            break;
        default:
            break;
    }
    return response
}, err => {
    let { status, statusText } = err.response
    switch (status) {
        case 404:
            Message.error(statusText)
            break;
        case 401:
            local.set('redirectUrl', window.location.href)
            router.push('/login');
            local.remove('sl_tk')
            break;
        case 500:
            Message.error(statusText)
            break;
        default:
            break;
    }
    return Promise.reject(err)
})

export default axios