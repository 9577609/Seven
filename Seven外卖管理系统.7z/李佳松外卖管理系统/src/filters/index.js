/**
 *  全局过滤器
 * 
 */

//  处理年月日时分秒
export const normalizeYMDhms = date => {
    const time = new Date(date);
    let H = time.getFullYear();
    let M = time.getMonth() + 1;
    let D = time.getDate();
    let h = time.getHours();
    let m = time.getMinutes();
    let s = time.getSeconds();
    return [H, M, D].map(v => String(v).padStart(2, '0')).join('/') + ' ' + [h, m, s].map(v => String(v).padStart(2, '0')).join(':')
}
//  处理年月日
export const normalizeYMD = date => {
    const time = new Date(date);
    let H = time.getFullYear();
    let M = time.getMonth() + 1;
    let D = time.getDate();
    let h = time.getHours();
    let m = time.getMinutes();
    let s = time.getSeconds();
    return [H, M, D].map(v => String(v).padStart(2, '0')).join('/')
}
//  处理时分秒
export const normalizeHMS = date => {
    const time = new Date(date);
    let H = time.getFullYear();
    let M = time.getMonth() + 1;
    let D = time.getDate();
    let h = time.getHours();
    let m = time.getMinutes();
    let s = time.getSeconds();
    return [h, m, s].map(v => String(v).padStart(2, '0')).join(':')
}

/* 超过1000加逗号 */
export const normalizeNum = n => {
    let num = n.toString()
    let decimals = ''
    // 判断是否有小数
    num.indexOf('.') > -1 ? decimals = num.split('.')[1] : decimals
    let len = num.length
    if (len <= 3) {
        return num
    } else {
        let temp = ''
        let remainder = len % 3
        decimals ? temp = '.' + decimals : temp
        if (remainder > 0) { // 不是3的整数倍
            return num.slice(0, remainder) + ',' + num.slice(remainder, len).match(/\d{3}/g).join(',') + temp
        } else { // 是3的整数倍
            return num.slice(0, len).match(/\d{3}/g).join(',') + temp
        }
    }
}