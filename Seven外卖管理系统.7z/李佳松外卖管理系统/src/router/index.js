import Vue from 'vue'
import VueRouter from 'vue-router'

import Login from '@/views/login/Login.vue'
import Layout from '@/views/layout/Layout.vue'
import local from "@/utils/local"
Vue.use(VueRouter)
// 解决重复点击路由报错的bug
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err)
}
const routes = [
  {
    path: '/',
    redirect: '/home',
    meta: { path: '/', address: '首页' }
  },
  {
    path: '/login',
    component: Login,
    meta: { path: '/login', address: '用户登录' }
  },
  {
    path: '/home',
    component: Layout,
    meta: { path: '/home', address: '后台首页' },
    children: [
      {
        path: '',
        component: () => import('@/views/home/Home.vue')
      }
    ]
  },
  {
    path: '/account',
    component: Layout,
    meta: { path: '/account', address: '账号管理' },
    redirect: '/account/account-list',
    children: [
      {
        path: '/account/account-add',
        meta: { path: '/account/account-add', address: '添加账号' },
        component: () => import('@/views/account/AccountAdd.vue')
      },
      {
        path: '/account/account-list',
        meta: { path: '/account/account-list', address: '账号列表' },
        component: () => import('@/views/account/AccountList.vue')
      },
      {
        path: '/account/account-center',
        meta: { path: '/account/account-center', address: '账号中心' },
        component: () => import('@/views/account/AccountCenter.vue')
      },
      {
        path: '/account/update-pwd',
        meta: { path: '/account/update-pwd', address: '修改密码' },
        component: () => import('@/views/account/UpdatePwd.vue')
      },
    ]
  },
  {
    path: '/goods',
    component: Layout,
    redirect: '/goods/goods-list',
    meta: { path: '/goods', address: '商品管理' },
    children: [
      {
        path: '/goods/goods-list',
        meta: { path: '/goods/goods-list', address: '商品列表' },
        component: () => import('@/views/goods/GoodsList.vue')
      },
      {
        path: '/goods/goods-add',
        meta: { path: '/goods/goods-add', address: '商品添加' },
        component: () => import('@/views/goods/GoodsAdd.vue')
      },
      {
        path: '/goods/goods-cate',
        meta: { path: '/goods/goods-cate', address: '商品分类' },
        component: () => import('@/views/goods/GoodsCate.vue')
      },

    ]
  },
  {
    path: '/order',
    meta: { path: '/order', address: '订单管理' },
    redirect: '/order/order-list',
    component: Layout,
    children: [
      {
        path: '/order/order-list',
        meta: { path: '/order/order-list', address: '订单列表' },
        component: () => import('@/views/order/OrderList.vue')
      },
      {
        path: '/order/order-update/:data',
        meta: { path: '/order/order-update', address: '订单编辑和查看' },
        component: () => import('@/views/order/OrderUpdate.vue')
      }
    ]
  },
  {
    path: '/shop',
    meta: { path: '/shop', address: '店铺管理' },
    component: Layout,
    children: [
      {
        path: '',
        component: () => import('@/views/shop/Shop.vue')
      }
    ]
  },
  {
    path: '/total',
    component: Layout,
    meta: { path: '/total', address: '销售统计' },
    redirect: '/total/total-goods',
    children: [
      {
        path: '/total/total-goods',
        meta: { path: '/total/total-goods', address: '商品统计' },
        component: () => import('@/views/total/TotalGoods.vue')
      },
      {
        path: '/total/total-order',
        meta: { path: '/total/total-order', address: '订单统计' },
        component: () => import('@/views/total/TotalOrder.vue')
      },
    ]
  },
]

const router = new VueRouter({
  routes
})

router.beforeEach((to, from, next) => {
  const token = local.get('sl_tk')

  const redirectUrl = local.get('redirectUrl')

  if (to.path !== '/login') {
    if (redirectUrl) {
      window.location.href = redirectUrl
      local.remove('redirectUrl')
    }
  }
  if (to.path !== '/login' && !token) next('/login')
  else next()
})

export default router
