/**
 * 店铺模块
 */

//引入工具函数层 request.js
import request from '@/utils/request';



/* 账号详情接口 */
export const getShopInfo = () => {
    return request({
        method: 'get',
        url: '/shop/info',
    })
}


/* 修改店铺接口 */
export const editShop = (data) => {
    return request({
        method: 'post',
        url: '/shop/edit',
        data
    })
}