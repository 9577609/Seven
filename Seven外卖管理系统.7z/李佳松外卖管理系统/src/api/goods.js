/**
 * 商品模块
 */

//引入工具函数层 request.js
import request from '@/utils/request';

/* 商品分类列表接口 */
export const getCateList = (params) => {
    return request({
        method: 'get',
        url: '/goods/catelist',
        params
    })
}

/* 修改分类接口 */
export const editCate = (data) => {
    return request({
        method: 'post',
        url: '/goods/editcate',
        data
    })
}

/* 添加分类接口 */
export const addCate = (data) => {
    return request({
        method: 'post',
        url: '/goods/addcate',
        data
    })
}

/* 删除分类接口 */
export const delCate = (params) => {
    return request({
        method: 'get',
        url: '/goods/delcate',
        params
    })
}

/* 获取所有分类 */
export const getCategories = (params) => {
    return request({
        method: 'get',
        url: '/goods/categories',
        params
    })
}


/* 获取商品列表接口 */
export const getGoodsList = (params) => {
    return request({
        method: 'get',
        url: '/goods/list',
        params
    })
}

/* 添加商品接口 */
export const goodsAdd = (data) => {
    return request({
        method: 'post',
        url: '/goods/add',
        data
    })
}

/* 修改商品接口 */
export const goodsEdit = (data) => {
    return request({
        method: 'post',
        url: '/goods/edit',
        data
    })
}

/* 删除商品接口 */
export const goodsDel = (params) => {
    return request({
        method: 'get',
        url: '/goods/del',
        params
    })
}