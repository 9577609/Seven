/**
 *      用户模块
 */

import request from '@/utils/request'

// 登录
export const checkLogin = (data) => {
    return request({
        method: 'post',
        url: '/users/checkLogin',
        data
    })
}
// 添加账号
export const usersAdd = (data) => {
    return request({
        method: 'post',
        url: '/users/add',
        data
    })
}
// 获取账号列表
export const getUsersList = (params) => {
    return request({
        method: 'get',
        url: '/users/list',
        params
    })
}
// 删除账号
export const usersDel = (params) => {
    return request({
        method: 'get',
        url: '/users/del',
        params
    })
}
// 批量删除账号
export const usersBatchdel = (params) => {
    return request({
        method: 'get',
        url: '/users/batchdel',
        params
    })
}
// 修改账号
export const editAccount = (data) => {
    return request({
        method: 'post',
        url: '/users/edit',
        data
    })
}
// 检查旧密码是否正确
export const checkOldPwd = (params) => {
    return request({
        method: 'get',
        url: '/users/checkoldpwd',
        params
    })
}
// 修改密码
export const editPwd = (data) => {
    return request({
        method: 'post',
        url: '/users/editpwd',
        data
    })
}
// 获取账号信息
export const getUserInfo = (params) => {
    return request({
        method: 'get',
        url: '/users/info',
        params
    })
}
// 上传头像
export const avatarUpload = (data) => {
    return request({
        method: 'post',
        url: '/users/avatar_upload',
        data
    })
}
// 修改用户头像
export const avatarEdit = (params) => {
    return request({
        method: 'get',
        url: '/users/avataredit',
        params
    })
}