/**
 * 订单模块
 */

import request from '@/utils/request';



// 获取订单列表
export const getOrderList = (params) => {
    return request({
        method: 'get',
        url: '/order/list',
        params
    })
}

// 修改订单
export const editOrder = (data) => {
    return request({
        method: 'post',
        url: '/order/edit',
        data
    })
}

/* 首页接口 */
export const getOrderTotalData = () => {
    return request({
        method: 'get',
        url: '/order/totaldata',
    })
}

/* 订单报表接口 */
export const getOrderTotal = (params) => {
    return request({
        method: 'get',
        url: '/order/ordertotal',
        params
    })
}