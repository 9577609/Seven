import Vue from 'vue'
import App from './App.vue'
import router from './router'

Vue.config.productionTip = false
// 重置、公用样式
import './assets/css/reset.css'
import './assets/css/property.css'
import './assets/css/normalize.css'

// 全局过滤器
import * as filters from '@/filters'
Object.keys(filters).forEach(v => {
  // 注册
  Vue.filter(v, filters[v])
})

// element-ui
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

Vue.use(ElementUI);

// 字体图标
import './assets/fonts/iconfont.css'

// 中央事件处理总线
Vue.prototype.$bus = new Vue()

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
